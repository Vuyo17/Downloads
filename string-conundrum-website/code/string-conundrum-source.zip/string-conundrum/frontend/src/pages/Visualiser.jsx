import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronLeft, ChevronRight, ChevronDown, Pause, Play, Volume2, VolumeX,
} from 'lucide-react';
import styles from '../styles/App.module.css';
import { SpeedControl } from '../components/SpeedControl';
import { useLanguage } from '../context/LanguageContext';
import { parseIndexInput, resolveIndex, sliceFromNotation } from '../utils/pythonStringOps';
import { SpeechUnavailableDialog } from '../components/SpeechUnavailableDialog';
import { joinSpeech, useSpeech } from '../utils/useSpeech';

// How long one step is held at 1× speed; the speed picker divides this.
const STEP_INTERVAL_MS = 800;

// ─── pure helpers ─────────────────────────────────────────────────────────────

// Python collapses a backslash escape in a non-raw string literal to the ONE
// character it names — "\n" is a single newline, "\t" a single tab — before
// the string even exists as a value. This tool used to skip that step
// entirely and hand the raw two-character "\" + "n" straight to the character
// grid, so `word = "Hello\nWorld!"` showed as 13 characters (with a literal
// backslash and a literal n) instead of Python's real 12. That's not a
// cosmetic gap — it's the exact misconception this project's own exercise
// feedback calls out elsewhere (escape_sequence_literal_confusion: "\n
// inside a string is a single newline character, not the two characters
// backslash and n"), so leaving it unhandled here actively taught the wrong
// thing on the one screen dedicated to showing students what a string
// actually contains.
//
// Covers the escapes CSC1015F material actually uses; an unrecognised
// sequence (e.g. "\q") is left as the literal two characters, matching
// Python's own behaviour for unknown escapes in a non-raw string.
const ESCAPE_MAP = {
  n: '\n', t: '\t', r: '\r', '0': '\0',
  a: '\x07', b: '\b', f: '\f', v: '\v',
  '\\': '\\', "'": "'", '"': '"',
};

function interpretEscapes(raw) {
  return raw.replace(/\\(.)/g, (whole, ch) => ESCAPE_MAP[ch] ?? whole);
}

function parseStringInput(value) {
  const match = value.match(/^\s*\w+\s*=\s*(["'])(.*)\1\s*$/);
  return match ? interpretEscapes(match[2]) : value;
}

// The shared slice resolver reports bounds in Python terms, where a negative
// step legitimately stops at -1. Clamp to the grid before using them to place
// the start/stop markers.
function sliceMarkerBounds(slice, length) {
  const clamp = (v) => Math.max(0, Math.min(length, v));
  return { start: clamp(slice.start ?? 0), stop: clamp(slice.stop ?? 0) };
}

function modeLabel(mode, t) {
  const map = {
    index: 'visualiser.modeIndex', slice: 'visualiser.modeSlicing',
    for_loop: 'visualiser.modeForLoop', while_loop: 'visualiser.modeWhileLoop',
    if_stmt: 'visualiser.modeIfStatement', method: 'visualiser.modeStringMethod',
  };
  return map[mode] ? t(map[mode]) : mode;
}

// ─── build steps for each mode ────────────────────────────────────────────────

function buildForSteps(text, rangeInput, t) {
  // rangeInput is like "0:5:1" — we use the chars at those indices
  const { picked, invalid, error } = sliceFromNotation(text, rangeInput);
  // `invalid`/`error` used to be dropped on the floor here: a malformed range
  // or a step of 0 just produced zero steps, `currentStep` stayed null, and
  // the ENTIRE step panel silently disappeared — no badge, no message,
  // nothing to say why. A single synthetic error step reuses the same
  // error-step rendering buildIfSteps already established, rather than the
  // step panel just not being there.
  if (invalid || error) {
    return [{
      iteration: 1,
      total: 1,
      charIndex: -1,
      char: '',
      highlight: [],
      event: 'for-error',
      error: true,
      description: error
        ? t('visualiser.sliceZeroStep')
        : t('visualiser.sliceInvalid', { slice: rangeInput }),
      variables: {},
    }];
  }
  const chars = text.split('');
  return picked.map((idx, iteration) => ({
    iteration: iteration + 1,
    total: picked.length,
    charIndex: idx,
    char: chars[idx] ?? '',
    highlight: [idx],
    description: t('visualiser.descForLoop', {
      n: iteration + 1, total: picked.length, ch: chars[idx] ?? '', i: idx,
    }),
    variables: { c: chars[idx] ?? '', i: idx },
  }));
}

function buildWhileSteps(text, whileInput, t) {
  // whileInput: "i < N" style — we simulate i=0..N-1 stepping through string
  const maxMatch = whileInput.match(/i\s*[<=>]+\s*(\d+)/);
  // An unrecognised condition (a typo, "i != 5" — `!` isn't in the matched
  // char class, or anything not shaped like "i <op> N") used to silently
  // fall back to "loop 5 times" with nothing said about why — indistinguish-
  // able from a real 5-iteration result the student actually asked for.
  if (!maxMatch) {
    return [{
      iteration: 1,
      total: 1,
      charIndex: -1,
      char: '',
      highlight: [],
      event: 'while-error',
      error: true,
      description: t('visualiser.whileConditionUnrecognised', { cond: whileInput }),
      variables: {},
    }];
  }
  const limit = Math.min(Number(maxMatch[1]), text.length);
  const steps = [];
  for (let i = 0; i < limit; i++) {
    // condition-check step
    steps.push({
      iteration: i + 1,
      total: limit,
      charIndex: i,
      char: text[i] ?? '',
      highlight: [i],
      event: 'while-cond',
      condition: whileInput,
      conditionResult: i < limit,
      description: t('visualiser.descWhileTrue', { cond: whileInput, i, ch: text[i] ?? '' }),
      variables: { i, 'text[i]': text[i] ?? '' },
    });
  }
  // final false step
  steps.push({
    iteration: limit + 1,
    total: limit,
    charIndex: -1,
    char: '',
    highlight: [],
    event: 'while-cond',
    condition: whileInput,
    conditionResult: false,
    description: t('visualiser.descWhileFalse', { cond: whileInput, i: limit }),
    variables: { i: limit },
  });
  return steps;
}

function buildIfSteps(text, expression, t) {
  // expression: e.g. "len(text) > 5" or "text[0] == 'H'"
  let result = false;
  // A malformed expression (unbalanced quotes, a typo, an unsupported
  // operator) used to be swallowed here — `result` fell back to its `false`
  // default and the step rendered as an ordinary, legitimate "condition is
  // False" instead of "this could not be evaluated at all". Cycle-1 feedback
  // called this out generally ("no error messages for string visualiser");
  // this is the most misleading instance of it, since a real False and a
  // silently-failed eval looked pixel-identical.
  let evalError = false;
  try {
    // safe eval: replace text with actual value, len() supported
    const safe = expression
      .replace(/\btext\b/g, JSON.stringify(text))
      .replace(/\blen\s*\(([^)]+)\)/g, (_, s) => {
        try { return JSON.parse(s).length; } catch { return 0; }
      });
    // eslint-disable-next-line no-new-func
    result = Boolean(new Function(`return (${safe})`)());
  } catch {
    evalError = true;
  }

  const errorDesc = t('visualiser.couldNotEvaluateDetail', { expr: expression });

  return [
    {
      iteration: 1,
      total: 2,
      charIndex: -1,
      char: '',
      highlight: evalError ? [] : (result ? text.split('').map((_, i) => i) : []),
      event: evalError ? 'if-error' : 'if',
      condition: expression,
      conditionResult: evalError ? undefined : result,
      error: evalError,
      description: evalError
        ? errorDesc
        : (result
            ? t('visualiser.descIfTrue', { expr: expression })
            : t('visualiser.descIfFalse', { expr: expression })),
      variables: evalError ? {} : { condition_result: result },
    },
    {
      iteration: 2,
      total: 2,
      charIndex: -1,
      char: '',
      highlight: [],
      event: evalError ? 'if-error' : 'if-done',
      condition: expression,
      conditionResult: evalError ? undefined : result,
      error: evalError,
      description: evalError
        ? errorDesc
        : (result
            ? t('visualiser.descIfDone')
            : t('visualiser.descElseDone')),
      variables: evalError ? {} : { condition_result: result },
    },
  ];
}

// ─── component ────────────────────────────────────────────────────────────────

export function Visualiser() {
  const { t, lang } = useLanguage();
  const speech = useSpeech(lang);
  const [mode, setMode] = useState('slice');
  const [stringInput, setStringInput] = useState('word = "Hello, World!"');
  const [indexInput, setIndexInput] = useState('2');
  const [sliceInput, setSliceInput] = useState('1:5');
  const [forInput, setForInput] = useState('0:13:1');
  const [whileInput, setWhileInput] = useState('i < 5');
  const [ifInput, setIfInput] = useState('len(text) > 5');
  const [methodInput, setMethodInput] = useState('upper');
  const [stepIndex, setStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  // Bumped by the Visualise button to replay the highlight animation.
  const [runId, setRunId] = useState(0);
  const playTimer = useRef(null);
  const stepsLenRef = useRef(0);

  const text = useMemo(() => parseStringInput(stringInput), [stringInput]);
  const chars = useMemo(() => text.split(''), [text]);
  const length = chars.length;

  // ── derived per-mode state ────────────────────────────────────────────────
  // Out-of-range indices stay out of range: Python raises IndexError, and
  // clamping to the nearest character would teach the opposite.
  const indexLookup = useMemo(() => {
    const parsed = parseIndexInput(indexInput);
    if (parsed === null) return { resolved: null, valid: false, parsed: null };
    return { ...resolveIndex(text, parsed), parsed };
  }, [indexInput, text]);

  const slice = useMemo(() => sliceFromNotation(text, sliceInput), [text, sliceInput]);

  const forSteps = useMemo(() => buildForSteps(text, forInput, t), [text, forInput, t]);
  const whileSteps = useMemo(() => buildWhileSteps(text, whileInput, t), [text, whileInput, t]);
  const ifSteps = useMemo(() => buildIfSteps(text, ifInput, t), [text, ifInput, t]);

  // { value, unsupported }, not a bare string: a typo or a real Python method
  // this teaching tool just hasn't implemented (count, replace, find, ...)
  // used to fall through to a FABRICATED result — `'text'.count()` printed as
  // if it had actually run, when nothing was evaluated at all. Cycle-1
  // feedback called this out generally ("no error messages ... why the error
  // happened"); this was the most actively misleading instance of it, since
  // the fake output looked exactly as confident as a real one.
  const methodResult = useMemo(() => {
    const m = methodInput.trim().toLowerCase();
    if (m === 'upper') return { value: text.toUpperCase() };
    if (m === 'lower') return { value: text.toLowerCase() };
    if (m === 'reverse') return { value: text.split('').reverse().join('') };
    if (m === 'strip') return { value: text.trim() };
    if (m === 'title') return { value: text.replace(/\b\w/g, c => c.toUpperCase()) };
    const lenMatch = m.match(/^len\s*\(?\s*\)?$/);
    if (lenMatch) return { value: String(length) };
    return { value: '', unsupported: true };
  }, [text, methodInput, length]);

  // ── active steps array for stepped modes ─────────────────────────────────
  const activeSteps = useMemo(() => {
    if (mode === 'for_loop') return forSteps;
    if (mode === 'while_loop') return whileSteps;
    if (mode === 'if_stmt') return ifSteps;
    return [];
  }, [mode, forSteps, whileSteps, ifSteps]);
  stepsLenRef.current = activeSteps.length;

  const currentStep = activeSteps[Math.min(stepIndex, activeSteps.length - 1)] ?? null;

  // ── computed highlight / output for simple modes ─────────────────────────
  const highlighted = useMemo(() => {
    if (mode === 'index') return indexLookup.valid ? [indexLookup.resolved] : [];
    if (mode === 'slice') return slice.picked;
    if (mode === 'method') return chars.map((_, i) => i);
    if (currentStep) return currentStep.highlight;
    return [];
  }, [mode, indexLookup, slice.picked, chars, currentStep]);

  const output = useMemo(() => {
    if (mode === 'index') return indexLookup.valid ? chars[indexLookup.resolved] : '';
    if (mode === 'slice') return slice.picked.map(i => chars[i] ?? '').join('');
    if (mode === 'method') return methodResult.value;
    if (currentStep) return currentStep.char || (currentStep.conditionResult !== undefined ? String(currentStep.conditionResult) : '');
    return '';
  }, [mode, indexLookup, chars, slice.picked, methodResult, currentStep]);

  // Declared here rather than beside the other label helpers further down:
  // the narration memo below reads it, and a `const` is not hoisted.
  const isStepped = ['for_loop', 'while_loop', 'if_stmt'].includes(mode);

  // ── result text for the simple modes (index/slice/method) ────────────────
  // { text, isError }. Single source of truth for both the output box and
  // narration below, covering every failure each mode can hit — a bare index
  // out of range, a non-numeric index, a malformed slice part, a zero slice
  // step (Python's ValueError), and a method this tool hasn't implemented.
  // Previously most of these either showed a bare "?" or silently rendered as
  // if they had succeeded (cycle-1 feedback: "no error messages for string
  // visualiser").
  const simpleResult = useMemo(() => {
    if (mode === 'index') {
      if (indexLookup.parsed === null) {
        return { text: t('visualiser.indexNotANumber', { index: indexInput }), isError: true };
      }
      if (!indexLookup.valid) {
        return {
          text: t('visualiser.indexOutOfRange', {
            index: indexInput,
            length,
            min: -Math.max(length, 1),
            max: Math.max(length - 1, 0),
          }),
          isError: true,
        };
      }
      return { text: `'${output}'`, isError: false };
    }
    if (mode === 'slice') {
      if (slice.error) return { text: t('visualiser.sliceZeroStep'), isError: true };
      if (slice.invalid) return { text: t('visualiser.sliceInvalid', { slice: sliceInput }), isError: true };
      return { text: `'${output}'`, isError: false };
    }
    if (mode === 'method') {
      if (methodResult.unsupported) {
        return { text: t('visualiser.methodUnsupported', { method: methodInput }), isError: true };
      }
      return { text: `'${output}'`, isError: false };
    }
    return { text: '', isError: false };
  }, [mode, indexLookup, indexInput, length, slice, sliceInput, methodResult, methodInput, output, t]);

  // ── spoken narration, for EVERY mode ──────────────────────────────────────
  // Stepped modes already author a per-step `description` that now includes
  // why the step happens (and, on error, the error name plus the reason).
  // Simple modes used to stop at "index 2 is l" / a bare exception name —
  // read-aloud also has to say why that is the answer, or what the error is
  // and why Python raised it.
  const narration = useMemo(() => {
    if (isStepped) return currentStep?.description ?? '';
    if (simpleResult.isError) return simpleResult.text;
    if (mode === 'index') {
      const char = chars[indexLookup.resolved];
      return joinSpeech(
        t('visualiser.narrationIndex', { index: indexInput, char }),
        indexLookup.parsed < 0
          ? t('visualiser.whyIndexNegative', {
              index: indexInput, resolved: indexLookup.resolved, char,
            })
          : t('visualiser.whyIndexPositive', { index: indexInput, char }),
      );
    }
    if (mode === 'slice') {
      const why = slice.step < 0
        ? t('visualiser.whySliceNegative', {
            start: slice.start, stop: slice.stop, step: slice.step,
          })
        : t('visualiser.whySlice', {
            start: slice.start, stop: slice.stop, step: slice.step,
          });
      return joinSpeech(
        t('visualiser.narrationSlice', { slice: sliceInput, output }),
        why,
        slice.picked.length === 0 && t('visualiser.whySliceEmpty'),
        (slice.startClamped || slice.stopClamped) && t('visualiser.whySliceClamped'),
      );
    }
    if (mode === 'method') {
      const m = methodInput.trim().toLowerCase();
      const whyKey = m === 'upper' ? 'visualiser.whyUpper'
        : m === 'lower' ? 'visualiser.whyLower'
        : m === 'reverse' ? 'visualiser.whyReverse'
        : m === 'strip' ? 'visualiser.whyStrip'
        : m === 'title' ? 'visualiser.whyTitle'
        : /^len\s*\(?\s*\)?$/.test(m) ? 'visualiser.whyLen'
        : null;
      return joinSpeech(
        t('visualiser.narrationMethod', { method: methodInput, output }),
        whyKey && t(whyKey),
      );
    }
    return '';
  }, [
    isStepped, currentStep, mode, simpleResult, indexLookup, indexInput, chars,
    slice, sliceInput, methodInput, output, t,
  ]);

  function advanceStep() {
    setStepIndex((prev) => {
      if (prev >= stepsLenRef.current - 1) {
        setIsPlaying(false);
        return prev;
      }
      return prev + 1;
    });
  }

  useEffect(() => {
    const wait = speech.enabled && isStepped && isPlaying;
    speech.speak(narration, wait ? advanceStep : undefined);
  }, [narration, speech.speak, speech.enabled, isStepped, isPlaying]);

  // ── reset step when mode / inputs change ──────────────────────────────────
  useEffect(() => {
    setStepIndex(0);
    clearInterval(playTimer.current);
    setIsPlaying(false);
  }, [mode, forInput, whileInput, ifInput, stringInput]);

  // ── auto-play ─────────────────────────────────────────────────────────────
  // Silent mode: `speed` multiplies the base interval. With read-aloud on,
  // the next step waits until the current sentence has finished speaking
  // (see the speak effect above) so the "why" is never cut off.
  useEffect(() => {
    if (!isPlaying || activeSteps.length === 0 || speech.enabled) return undefined;
    playTimer.current = setInterval(advanceStep, STEP_INTERVAL_MS / speed);
    return () => clearInterval(playTimer.current);
  }, [isPlaying, activeSteps.length, speed, speech.enabled]);

  function stopPlay() { clearInterval(playTimer.current); setIsPlaying(false); }

  // The board is derived live from the inputs, so "Visualise" is about *running*
  // it: stepped modes replay from the first step, and every mode re-triggers the
  // highlight animation so the press has a visible effect.
  function handleVisualise() {
    stopPlay();
    setStepIndex(0);
    setRunId((n) => n + 1);
    if (isStepped && activeSteps.length > 0) setIsPlaying(true);
  }

  function prevStep() { stopPlay(); setStepIndex(i => Math.max(0, i - 1)); }
  function nextStep() { stopPlay(); setStepIndex(i => Math.min(activeSteps.length - 1, i + 1)); }
  function togglePlay() {
    if (activeSteps.length === 0) return;
    if (isPlaying) { stopPlay(); return; }
    if (stepIndex >= activeSteps.length - 1) setStepIndex(0);
    setIsPlaying(true);
  }

  // ── label helpers ─────────────────────────────────────────────────────────
  const markerBounds = sliceMarkerBounds(slice, length);

  const fieldLabel = {
    index: t('visualiser.fieldIndex'),
    slice: t('visualiser.fieldSlice'),
    for_loop: t('visualiser.fieldForLoop'),
    while_loop: t('visualiser.fieldWhileLoop'),
    if_stmt: t('visualiser.fieldIfStatement'),
    method: t('visualiser.fieldMethod'),
  }[mode] ?? t('visualiser.fieldExpression');

  const currentInput = {
    index: indexInput, slice: sliceInput, for_loop: forInput,
    while_loop: whileInput, if_stmt: ifInput, method: methodInput,
  }[mode] ?? '';

  const setCurrentInput = {
    index: setIndexInput, slice: setSliceInput, for_loop: setForInput,
    while_loop: setWhileInput, if_stmt: setIfInput, method: setMethodInput,
  }[mode] ?? (() => {});

  const operationText = {
    index: `text[${indexInput}]`,
    slice: `text[${sliceInput}]`,
    for_loop: `for c in text[${forInput}]:`,
    while_loop: `while ${whileInput}:`,
    if_stmt: `if ${ifInput}:`,
    method: `text.${methodInput}()`,
  }[mode] ?? '';

  // ─── render ─────────────────────────────────────────────────────────────────
  return (
    <div className={styles.visualiserScreen}>
      <header className={styles.visualiserHeader}>
        <h1>{t('visualiser.title')}</h1>
        <p>{t('visualiser.subtitle')}</p>
      </header>

      {/* ── control card ── */}
      <section className={styles.visualiserControlCard}>
        <label className={styles.visualiserField}>
          <span>{t('visualiser.enterString')}</span>
          <input
            value={stringInput}
            onChange={e => setStringInput(e.target.value)}
            maxLength={50}
          />
          <small>{t('visualiser.characterCount', { count: text.length })}</small>
        </label>

        <label className={styles.visualiserField}>
          <span>{fieldLabel}</span>
          <input
            value={currentInput}
            onChange={e => setCurrentInput(e.target.value)}
          />
          <small>
            {{
              index: t('visualiser.hintIndex', {
                min: Math.max(length, 1),
                max: Math.max(length - 1, 0),
              }),
              slice: t('visualiser.hintSlice'),
              for_loop: t('visualiser.hintForLoop'),
              while_loop: t('visualiser.hintWhileLoop'),
              if_stmt: t('visualiser.hintIfStatement'),
              // Method names only — no prose, and they stay English because the
              // student types them verbatim.
              method: 'upper · lower · reverse · strip · title · len()',
            }[mode] ?? ''}
          </small>
        </label>

        <label className={styles.visualiserField}>
          <span>{t('visualiser.selectMode')}</span>
          <div className={styles.visualiserSelectWrap}>
            <select value={mode} onChange={e => setMode(e.target.value)}>
              <option value="slice">{t('visualiser.modeSlicing')}</option>
              <option value="index">{t('visualiser.modeIndex')}</option>
              <option value="for_loop">{t('visualiser.modeForLoop')}</option>
              <option value="while_loop">{t('visualiser.modeWhileLoop')}</option>
              <option value="if_stmt">{t('visualiser.modeIfStatement')}</option>
              <option value="method">{t('visualiser.modeStringMethod')}</option>
            </select>
            <ChevronDown size={22} />
          </div>
        </label>

        <button
          type="button"
          className={styles.visualiseButton}
          onClick={handleVisualise}
          disabled={length === 0}
          title={length === 0
            ? t('visualiser.enterStringFirst')
            : t('visualiser.runVisualisation')}
        >
          {isStepped && isPlaying ? t('visualiser.playing') : t('visualiser.visualise')}
        </button>
      </section>

      {/* ── board ── */}
      <section className={styles.visualiserBoard}>
        <div className={styles.visualiserBoardTop}>
          <div><strong>{t('visualiser.stringLabel')}</strong>{' '}
            <span>{stringInput.includes('=') ? `"${text}"` : text}</span>
          </div>
          <div className={styles.operationBadge}>{operationText}</div>
          <div><strong>{t('visualiser.modeLabel')}</strong> <span>{modeLabel(mode, t)}</span></div>
        </div>

        {/* stepped-mode progress + description */}
        {isStepped && currentStep && (
          <div className={styles.visStepPanel}>
            <div className={styles.visStepProgressBar}>
              <div
                className={styles.visStepProgressFill}
                style={{ width: `${((stepIndex + 1) / activeSteps.length) * 100}%` }}
              />
            </div>
            <div className={styles.visStepInfo}>
              <span className={styles.visStepCount}>
                {t('visualiser.stepCount', { current: stepIndex + 1, total: activeSteps.length })}
              </span>
              {currentStep.error ? (
                <span
                  className={styles.visCondBadge}
                  style={{ background: '#fde8e8', color: '#d32f2f' }}
                >
                  {t('visualiser.evalErrorBadge')}
                </span>
              ) : currentStep.conditionResult !== undefined && (
                <span
                  className={styles.visCondBadge}
                  style={{
                    background: currentStep.conditionResult ? '#c8f7e1' : '#fde8e8',
                    color: currentStep.conditionResult ? '#0e8a6b' : '#d32f2f',
                  }}
                >
                  {currentStep.conditionResult
                    ? t('visualiser.conditionTrueBadge')
                    : t('visualiser.conditionFalseBadge')}
                </span>
              )}
              {/* No iteration badge: it only rendered for for_loop, where one
                  step is exactly one iteration, so it restated the step
                  counter beside it verbatim. The iteration is still named in
                  the step description below (descForLoop). */}
            </div>
            <div className={`${styles.visStepDesc} ${currentStep.error ? styles.visStepDescError : ''}`}>
              {currentStep.description}
            </div>

            {/* variable mini-table */}
            {currentStep.variables && Object.keys(currentStep.variables).length > 0 && (
              <div className={styles.visVarRow}>
                {Object.entries(currentStep.variables).map(([k, v]) => (
                  <span key={k} className={styles.visVarChip}>
                    <strong>{k}</strong> = {typeof v === 'string' ? `"${v}"` : String(v)}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}

        {/* character grid */}
        <div className={styles.visualRows}>
          <div className={styles.rowLabel}>{t('visualiser.rowIndex')}</div>
          <div className={styles.visualGrid} style={{ '--cells': Math.max(length, 1) }}>
            {chars.map((_, index) => (
              <span key={`p-${index}`} className={styles.indexNumber}>{index}</span>
            ))}
            {chars.map((_, index) => (
              <span key={`n-${index}`} className={styles.negativeNumber}>{index - length}</span>
            ))}
          </div>

          <div className={styles.rowLabel}>{t('visualiser.rowChar')}</div>
          <div className={styles.visualGrid} style={{ '--cells': Math.max(length, 1) }}>
            {chars.map((char, index) => {
              const active = highlighted.includes(index);
              return (
                <span
                  // runId is part of the key so a Visualise press remounts the
                  // cells and replays the highlight animation.
                  key={`${char}-${index}-${runId}`}
                  className={[
                    styles.visualChar,
                    active ? styles.visualCharActive : '',
                    active ? styles.visualCharPulse : '',
                  ].join(' ')}
                  style={active ? { animationDelay: `${Math.min(highlighted.indexOf(index) * 60, 600)}ms` } : undefined}
                >
                  {char}
                </span>
              );
            })}
          </div>

          {/* markers row */}
          <div className={styles.rowLabel} />
          {mode === 'slice' ? (
            <div className={styles.sliceGrid} style={{ '--cells': Math.max(length, 1) }}>
              <div
                className={styles.sliceBracket}
                style={{
                  gridColumn: `${Math.min(markerBounds.start, markerBounds.stop) + 1} / ${Math.max(markerBounds.start, markerBounds.stop) + 1}`,
                }}
              />
              {/* Red when the typed bound was out of range and Python
                  clamped it (e.g. stop=30 on a 13-char string lands at 13)
                  — clamping isn't an error (no ValueError, unlike indexing),
                  but showing the adjusted number with no visual sign it had
                  been changed at all read as "did my input even get used?" */}
              <span
                className={`${styles.sliceStart} ${slice.startClamped ? styles.sliceMarkerClamped : ''}`}
                style={{ gridColumn: `${markerBounds.start + 1}` }}
              >
                ▲<strong>{t('visualiser.start')}: {slice.start}</strong>
                <small>{slice.startClamped ? t('visualiser.clamped') : t('visualiser.inclusive')}</small>
              </span>
              <span
                className={`${styles.sliceStop} ${slice.stopClamped ? styles.sliceMarkerClamped : ''}`}
                style={{ gridColumn: `${markerBounds.stop + 1}` }}
              >
                ▲<strong>{t('visualiser.stop')}: {slice.stop}</strong>
                <small>{slice.stopClamped ? t('visualiser.clamped') : t('visualiser.exclusive')}</small>
              </span>
            </div>
          ) : (
            <div className={styles.markerGrid} style={{ '--cells': Math.max(length, 1) }}>
              {chars.map((_, index) => {
                const active = highlighted.includes(index);
                return (
                  <span key={`marker-${index}`} className={active ? styles.markerActive : ''}>
                    {active && (
                      <>
                        ▲
                        <strong>
                          {mode === 'for_loop' && currentStep ? currentStep.char || index
                            : mode === 'while_loop' && currentStep ? `i=${currentStep.variables?.i ?? index}`
                              : index}
                        </strong>
                        {mode === 'for_loop' && currentStep && (
                          <small>iter {currentStep.iteration}/{currentStep.total}</small>
                        )}
                      </>
                    )}
                  </span>
                );
              })}
            </div>
          )}
        </div>

        {/* output box */}
        <div
          className={`${styles.visualiserOutput} ${
            (isStepped ? currentStep?.error : simpleResult.isError)
              ? styles.visualiserOutputError
              : ''
          }`}
          aria-live="polite"
        >
          <strong>{t('visualiser.output')}</strong>
          <code className={
            (isStepped ? currentStep?.error : simpleResult.isError)
              ? styles.visStepDescError
              : ''
          }>
            {/* Any stepped mode's error step (if_stmt eval failure, an
                invalid for-loop range, an unrecognised while condition)
                takes priority over the mode-specific rendering below — same
                error text as the step panel above, so the box never shows a
                stale/blank result next to a visible error banner. */}
            {isStepped && currentStep?.error
              ? currentStep.description
              : mode === 'if_stmt'
                ? (currentStep?.conditionResult !== undefined
                    ? (currentStep.conditionResult
                        ? t('visualiser.ifBodyRuns')
                        : t('visualiser.elseRuns'))
                    : '?')
                // index/slice/method have real simpleResult logic (success
                // text or an error message); for_loop/while_loop fall back to
                // plain `output` (the current step's character) same as
                // before the error-step work above.
                : (mode === 'index' || mode === 'slice' || mode === 'method')
                  ? simpleResult.text
                  : `'${output}'`}
          </code>
        </div>
        {/* Simple modes have no step panel, so the "why this is the answer /
            what the error is and why" line lives here — same string that
            read-aloud speaks. Stepped modes already show it as visStepDesc. */}
        {!isStepped && !simpleResult.isError && narration && (
          <p className={styles.visualiserNarration} aria-live="polite">
            {narration}
          </p>
        )}
      </section>

      {/* ── speed picker (own row, above the playback controls) ── */}
      <div className={styles.visualiserSpeedRow}>
        <SpeedControl value={speed} onChange={setSpeed} disabled={!isStepped} />
        {/* Not gated on isStepped, unlike the speed picker: every mode now
            produces a narration line (see the memo above), so read-aloud is
            useful on the simple index/slice/method modes too. */}
        {speech.supported && (
          <button
            type="button"
            className={styles.vizSpeakButton}
            onClick={speech.toggle}
            aria-pressed={speech.enabled}
            title={
              speech.available
                ? (speech.enabled ? t('viz.readAloudOff') : t('viz.readAloudOn'))
                : t('viz.readAloudUnavailable')
            }
          >
            {speech.enabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
            {t('viz.readAloud')}
          </button>
        )}
        <SpeechUnavailableDialog open={speech.noticeOpen} onClose={speech.dismissNotice} />
      </div>

      {/* ── playback controls ── */}
      <section className={styles.visualiserControls}>
        <button onClick={prevStep} disabled={!isStepped || stepIndex === 0}>
          <ChevronLeft size={28} /> {t('common.previous')}
        </button>
        <button
          className={styles.playButton}
          onClick={isStepped ? togglePlay : undefined}
          disabled={!isStepped}
        >
          {isPlaying ? <Pause size={26} /> : <Play size={26} />}
          {isPlaying ? t('common.pause') : t('common.play')}
        </button>
        <button onClick={nextStep} disabled={!isStepped || stepIndex === activeSteps.length - 1}>
          {t('common.next')} <ChevronRight size={28} />
        </button>
      </section>
    </div>
  );
}
