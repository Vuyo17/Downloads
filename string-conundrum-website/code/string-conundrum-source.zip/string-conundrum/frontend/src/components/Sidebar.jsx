import React from 'react';
import {
  LayoutGrid, Eye, Code2, Trophy, Sparkles, Lock, Target,
  Settings, LogOut, BookOpen, LayoutDashboard,
} from 'lucide-react';
import styles from '../styles/App.module.css';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

// Screen ids stay English — they key the router, `canAccess` and the screen map
// in App.jsx. Only the visible label is translated, via `labelKey`.
const NAV_ITEMS = [
  { id: 'Modules', icon: LayoutGrid, labelKey: 'nav.modules' },
  { id: 'Visualiser', icon: Eye, labelKey: 'nav.visualiser' },
  { id: 'Code Space', icon: Code2, labelKey: 'nav.codeSpace' },
  { id: 'Challenges', icon: Target, labelKey: 'nav.challenges' },
  { id: 'Leaderboard', icon: Trophy, labelKey: 'nav.leaderboard' },
  { id: 'Docs', icon: BookOpen, labelKey: 'nav.docs' },
];

export function Sidebar({ screen, setScreen, modulesComplete, isAdmin }) {
  const { isGuest, canAccess, signOut } = useAuth();
  const { t } = useLanguage();

  return (
    <aside className={styles.sidebar}>
      {isGuest && (
        <div className={styles.sideStreakBanner}>
          <div className={styles.sideStreakLabel}>
            <Sparkles size={12} /> {t('nav.guestMode')}
          </div>
          <p className={styles.sideStreakText}>{t('nav.guestBlurb')}</p>
          <button className={styles.sideUnlockBtn} onClick={signOut}>
            {t('nav.signInToUnlock')}
          </button>
        </div>
      )}

      {isAdmin && (
        // Appended for lecturers rather than filtered out of NAV_ITEMS for
        // everyone else, so the student sidebar is byte-for-byte what it
        // always was and only an admin session grows an extra item. Hiding it
        // is a convenience: the screen and every endpoint behind it are gated
        // server-side too.
        <button
          className={screen === 'Dashboard' ? styles.sideActive : ''}
          onClick={() => setScreen('Dashboard')}
        >
          <LayoutDashboard size={17} />
          {t('nav.dashboard')}
        </button>
      )}

      {NAV_ITEMS.map(({ id, icon: Icon, labelKey }) => {
        const signedInOnly = !canAccess(id);
        const needsModules = id === 'Challenges' && !modulesComplete;
        const locked = signedInOnly || needsModules;
        const lockMessage = signedInOnly
          ? t('nav.signInToUnlock')
          : needsModules
          ? t('nav.completeModulesToUnlock')
          : undefined;
        return (
          <button
            key={id}
            className={`${screen === id ? styles.sideActive : ''} ${locked ? styles.sideLocked : ''}`}
            onClick={() => {
              if (signedInOnly) return signOut();
              if (needsModules) return;
              setScreen(id);
            }}
            title={lockMessage}
          >
            {Icon && <Icon size={17} />}
            {t(labelKey)}
            {locked && <Lock size={13} className={styles.sideLockIcon} />}
          </button>
        );
      })}

      <div className={styles.sideBottomSection}>
        <button
          className={screen === 'Settings' ? styles.sideActive : ''}
          onClick={() => setScreen('Settings')}
        >
          <Settings size={17} />
          {t('nav.settings')}
        </button>

        <button
          className={styles.sideSignOutBtn}
          onClick={signOut}
          title={isGuest ? t('nav.signIn') : t('nav.signOut')}
        >
          <LogOut size={15} />
          {isGuest ? t('nav.signIn') : t('nav.signOut')}
        </button>
      </div>
    </aside>
  );
}
