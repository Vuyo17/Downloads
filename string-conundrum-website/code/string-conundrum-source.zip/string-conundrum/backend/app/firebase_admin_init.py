"""Firebase Admin SDK initialisation.

No credentials are distributed with this source archive. Supply the Firebase
service-account credential at deploy time through either:

  * FIREBASE_SERVICE_ACCOUNT_JSON   the service-account JSON document itself, or
  * GOOGLE_APPLICATION_CREDENTIALS  a filesystem path to the service-account JSON.
"""
import json
import os

import firebase_admin
from firebase_admin import credentials


def _load_credential():
    raw = os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON")
    if raw:
        return credentials.Certificate(json.loads(raw))
    path = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
    if path:
        return credentials.Certificate(path)
    raise RuntimeError(
        "Firebase Admin credential not configured: set FIREBASE_SERVICE_ACCOUNT_JSON "
        "or GOOGLE_APPLICATION_CREDENTIALS."
    )


def init_firebase_admin():
    if firebase_admin._apps:
        return firebase_admin.get_app()

    return firebase_admin.initialize_app(_load_credential())
