# About this archive

This is a snapshot of the `production` branch of the String Conundrum
repository (https://github.com/Vuyo17/string-conundrum) at commit
`5538ca9` (2026-09-30). It is the version that was deployed to the UCT
Computer Science host for the final evaluation.

Authors: Hlomla Kuhlane (front end) and Luvuyo Matomela (back end),
Department of Computer Science, University of Cape Town, 2026.

## Difference from the repository

`backend/app/firebase_admin_init.py` has been replaced with a version that
reads the Firebase Admin service-account credential from the environment
(`FIREBASE_SERVICE_ACCOUNT_JSON` or `GOOGLE_APPLICATION_CREDENTIALS`), so
that no credentials are distributed with this archive. Every other file is
identical to the commit above.

## Running it

See `README.md` for local development (React + Vite front end, Flask back
end, PostgreSQL or the JSON-file fallback via `LOCAL_DB_FALLBACK=1`).
